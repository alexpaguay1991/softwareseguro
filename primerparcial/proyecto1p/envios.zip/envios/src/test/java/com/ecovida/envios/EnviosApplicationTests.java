package com.ecovida.envios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnviosApplicationTests {

	@Test
	void contextLoads() {
	}

}
