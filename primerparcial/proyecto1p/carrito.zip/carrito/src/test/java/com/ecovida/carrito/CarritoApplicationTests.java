package com.ecovida.carrito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarritoApplicationTests {

	@Test
	void contextLoads() {
	}

}
