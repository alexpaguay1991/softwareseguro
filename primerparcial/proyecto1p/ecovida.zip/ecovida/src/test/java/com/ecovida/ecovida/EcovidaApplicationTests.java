package com.ecovida.ecovida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcovidaApplicationTests {

	@Test
	void contextLoads() {
	}

}
