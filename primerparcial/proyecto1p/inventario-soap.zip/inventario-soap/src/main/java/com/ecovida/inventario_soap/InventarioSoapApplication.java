package com.ecovida.inventario_soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioSoapApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioSoapApplication.class, args);
	}

}
