package com.ecovida.soapinventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapinventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapinventarioApplication.class, args);
	}

}
