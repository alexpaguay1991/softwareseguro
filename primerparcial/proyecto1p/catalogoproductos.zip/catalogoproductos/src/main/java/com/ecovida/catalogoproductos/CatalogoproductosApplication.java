package com.ecovida.catalogoproductos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoproductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoproductosApplication.class, args);
	}

}
