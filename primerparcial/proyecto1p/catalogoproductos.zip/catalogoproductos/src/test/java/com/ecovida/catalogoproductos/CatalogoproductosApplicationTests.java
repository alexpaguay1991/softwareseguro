package com.ecovida.catalogoproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoproductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
