package com.example.demosoap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSoapApplicationTests {

	@Test
	void contextLoads() {
	}

}
